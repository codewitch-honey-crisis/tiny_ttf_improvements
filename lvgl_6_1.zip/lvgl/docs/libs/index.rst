.. _3rd_party_libraries:

===================
3rd party libraries
===================


.. toctree::
    :maxdepth: 1

    fs
    bmp
    tjpgd
    libjpeg_turbo
    lodepng
    libpng
    gif
    freetype
    tiny_ttf
    qrcode
    barcode
    rlottie
    ffmpeg
    rle
    arduino_esp_littlefs
    arduino_sd
    lfs
