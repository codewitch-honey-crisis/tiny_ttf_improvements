.. _new_widget:

==========
New widget
==========
